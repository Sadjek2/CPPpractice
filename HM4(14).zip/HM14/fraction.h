// fraction.h
#ifndef FRACTION_H
#define FRACTION_H

#include <iostream>
#include <stdexcept>

// Своя функция НОД
int gcd(int a, int b)
{
    while (b != 0)
    {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

class Fraction
{
private:
    int numerator_;
    int denominator_;

    void reduce()
    {
        if (denominator_ == 0)
            throw std::invalid_argument("Denominator cannot be zero");

        if (denominator_ < 0)
        {
            numerator_ = -numerator_;
            denominator_ = -denominator_;
        }

        int g = gcd(std::abs(numerator_), denominator_);
        if (g != 0)
        {
            numerator_ /= g;
            denominator_ /= g;
        }
    }

public:
    explicit Fraction(int num = 0, int den = 1) : numerator_(num), denominator_(den)
    {
        reduce();
    }

    void print() const { std::cout << numerator_ << '/' << denominator_; }

    friend std::ostream& operator<<(std::ostream& os, const Fraction& f)
    {
        os << f.numerator_ << '/' << f.denominator_;
        return os;
    }

    int numerator()   const { return numerator_; }
    int denominator() const { return denominator_; }

    Fraction operator+(const Fraction& other) const
    {
        return Fraction(
            numerator_ * other.denominator_ + other.numerator_ * denominator_,
            denominator_ * other.denominator_
        );
    }

    Fraction operator+(int num) const { return *this + Fraction(num, 1); }

    friend Fraction operator+(int num, const Fraction& f) { return Fraction(num, 1) + f; }

    Fraction operator-(const Fraction& other) const
    {
        return Fraction(
            numerator_ * other.denominator_ - other.numerator_ * denominator_,
            denominator_ * other.denominator_
        );
    }

    Fraction operator-(int num) const { return *this - Fraction(num, 1); }

    friend Fraction operator-(int num, const Fraction& f) { return Fraction(num, 1) - f; }

    Fraction operator*(const Fraction& other) const
    {
        return Fraction(
            numerator_ * other.numerator_,
            denominator_ * other.denominator_
        );
    }

    Fraction operator*(int num) const { return *this * Fraction(num, 1); }

    friend Fraction operator*(int num, const Fraction& f) { return Fraction(num, 1) * f; }
};

#endif