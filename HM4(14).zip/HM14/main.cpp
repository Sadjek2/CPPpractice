// main.cpp
#include "fraction.h"


int main()
{
    Fraction a(2, 4);   // 1/2
    Fraction b(3, 9);  // 1/3

    std::cout << "a = " << a << std::endl;
    std::cout << "b = " << b << std::endl;
    std::cout << "a + b = " << a + b << std::endl;
    std::cout << "a - b = " << a - b << std::endl;
    std::cout << "a * b = " << a * b << std::endl;
    std::cout << "a + 1 = " << a + 1 << std::endl;
    std::cout << "2 - a = " << 2 - a << std::endl;
    std::cout << "b * 3 = " << b * 3 << std::endl;
    std::cout << "1 - a + b = " << 1 - a + b << std::endl;

    return 0;
}