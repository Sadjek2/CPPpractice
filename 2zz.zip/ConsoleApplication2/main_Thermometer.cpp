#include <iostream>
#include <conio.h>
#include "Thermometer.h"

int main() {
    // Демонстрация всех трех конструкторов
    Thermometer t1;                    // по умолчанию
    Thermometer t2(25.5);             // только температура
    Thermometer t3("Street", -5.2);   // полный

    cout << "=== Thermometer 1 (default) ===" << endl;
    t1.printInfo();

    cout << "=== Thermometer 2 (temperature only) ===" << endl;
    t2.printInfo();

    cout << "=== Thermometer 3 (location + temperature) ===" << endl;
    t3.printInfo();

    _getch();
    return 0;
}