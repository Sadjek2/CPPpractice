#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class Thermometer {
private:
    double celsius;        // температура в Цельсиях
    char* location;        // место измерения (динамическая строка)

public:
    Thermometer();                             // конструктор по умолчанию
    Thermometer(double tempCelsius);           // перегруженный конструктор 1
    Thermometer(const char* place, double tempCelsius);  // перегруженный конструктор 2
    double getCelsius() const;                 // const геттер
    double getFahrenheit() const;              // конвертация в Фаренгейты
    void printInfo() const;                    // const метод вывода
    ~Thermometer();                            // деструктор
};