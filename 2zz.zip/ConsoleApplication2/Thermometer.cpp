#include "Thermometer.h"

// Конструктор по умолчанию: 0'C, "Unknown"
Thermometer::Thermometer() {
    celsius = 0.0;
    location = new char[10];
    strcpy_s(location, 10, "Unknown");
}

// Конструктор с температурой: location = "Unknown"
Thermometer::Thermometer(double tempCelsius) {
    celsius = tempCelsius;
    location = new char[10];
    strcpy_s(location, 10, "Unknown");
}

// Полный конструктор
Thermometer::Thermometer(const char* place, double tempCelsius) {
    celsius = tempCelsius;
    location = new char[strlen(place) + 1];
    strcpy_s(location, strlen(place) + 1, place);
}

// Формула: F = C * 9/5 + 32
double Thermometer::getFahrenheit() const {
    return celsius * 9.0 / 5.0 + 32.0;
}

double Thermometer::getCelsius() const {
    return celsius;
}

void Thermometer::printInfo() const {
    cout << "Location: " << location << endl;
    cout << "Temperature: " << celsius << "'C ("
        << getFahrenheit() << "'F)" << endl;
    cout << "------------------------" << endl;
}

Thermometer::~Thermometer() {
    delete[] location;
}