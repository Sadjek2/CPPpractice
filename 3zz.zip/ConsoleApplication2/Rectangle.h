#pragma once
#include <iostream>
#include <iomanip>
using namespace std;

class Rectangle {
private:
    double width;   // ширина (private - инкапсуляция)
    double height;  // высота

public:
    Rectangle(double w, double h);  // конструктор с проверками > 0

    // Inline методы с const (не изменяют объект)
    double getWidth() const { return width; }
    double getHeight() const { return height; }
    double getArea() const { return width * height; }           // площадь
    double getPerimeter() const { return 2 * (width + height); } // периметр
    bool isSquare() const { return width == height; }           // квадрат?

    void printInfo() const;  // const метод вывода
};