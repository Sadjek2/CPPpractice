#include "Rectangle.h"

// Конструктор: если w/h <= 0, устанавливаем 1.0
Rectangle::Rectangle(double w, double h) {
    width = (w > 0) ? w : 1.0;
    height = (h > 0) ? h : 1.0;
}

void Rectangle::printInfo() const {
    cout << fixed << setprecision(2);  // форматированный вывод (2 знака)
    cout << "Rectangle: " << width << " x " << height << endl;
    cout << "Area: " << getArea() << endl;
    cout << "Perimeter: " << getPerimeter() << endl;
    cout << "Is square: " << (isSquare() ? "yes" : "no") << endl;
    cout << "------------------------" << endl;
}