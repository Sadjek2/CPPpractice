#include <iostream>
#include <conio.h>
#include "Rectangle.h"

int main() {
    Rectangle rect1(5.0, 3.0);     // обычный прямоугольник
    Rectangle rect2(4.0, 4.0);     // квадрат
    Rectangle rect3(-2.0, -3.0);   // тест отрицательных значений

    cout << "=== Rectangle 5.0 x 3.0 ===" << endl;
    rect1.printInfo();

    cout << "=== Square 4.0 x 4.0 ===" << endl;
    rect2.printInfo();

    cout << "=== Test with negative values (-2 x -3) ===" << endl;
    rect3.printInfo();

    _getch();
    return 0;
}