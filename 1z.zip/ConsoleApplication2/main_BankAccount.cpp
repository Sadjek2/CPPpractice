#include <iostream>
#include <conio.h>
#include "BankAccount.h"

int main() {
    // Создаем счет с начальными данными
    BankAccount account("Ivan Petrov", 12345, 1000.0);

    cout << "=== Account Information ===" << endl;
    account.printInfo();

    // Тестируем пополнение (успешное и ошибочное)
    account.deposit(500.0);
    account.deposit(-100.0);

    // Тестируем снятие (успешное и ошибочное)
    account.withdraw(300.0);
    account.withdraw(2000.0);

    cout << "\n=== Final Information ===" << endl;
    account.printInfo();

    _getch();
    return 0;
}