#include "BankAccount.h"

// Конструктор: выделяем память под имя, проверяем initialBalance >= 0
BankAccount::BankAccount(const char* ownerName, int accNum, double initialBalance) {
    owner = new char[strlen(ownerName) + 1];  // динамическое выделение памяти
    strcpy_s(owner, strlen(ownerName) + 1, ownerName);
    accountNumber = accNum;

    if (initialBalance < 0) {
        balance = 0.0;
        cout << "Warning: initial balance was negative. Set to 0.0" << endl;
    }
    else {
        balance = initialBalance;
    }
}

// Пополнение: только положительные суммы
void BankAccount::deposit(double amount) {
    if (amount > 0) {
        balance += amount;
        cout << "Deposited " << amount << ". New balance: " << balance << endl;
    }
    else {
        cout << "Error: deposit amount must be positive!" << endl;
    }
}

// Снятие: проверяем баланс и положительность суммы (ИСПРАВЛЕНО!)
bool BankAccount::withdraw(double amount) {  // ← Добавил BankAccount::
    if (amount > balance || amount <= 0) {
        cout << "Error: insufficient funds or invalid amount! Balance: "
            << balance << ", requested: " << amount << endl;
        return false;
    }
    balance -= amount;
    cout << "Withdrawn " << amount << ". New balance: " << balance << endl;
    return true;
}

double BankAccount::getBalance() {
    return balance;
}

void BankAccount::printInfo() {
    cout << "Owner: " << owner << endl;
    cout << "Account #: " << accountNumber << endl;
    cout << "Balance: " << balance << " USD" << endl;
}

// Освобождаем динамически выделенную память
BankAccount::~BankAccount() {
    delete[] owner;
}