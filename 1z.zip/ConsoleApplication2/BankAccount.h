#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class BankAccount {
private:
    char* owner;           // динамическая строка с именем владельца
    int accountNumber;     // номер счета
    double balance;        // баланс счета (инкапсуляция - private)

public:
    BankAccount(const char* ownerName, int accNum, double initialBalance);  // конструктор с проверками
    void deposit(double amount);       // пополнение с проверкой > 0
    bool withdraw(double amount);      // снятие с проверкой баланса
    double getBalance();               // геттер баланса
    void printInfo();                  // вывод информации
    ~BankAccount();                    // деструктор для освобождения памяти
};