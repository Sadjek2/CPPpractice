#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include <iomanip>
#include <string>

class Product {
public:
    std::string name;
    int quantity;
    double price;

    void print() {
        std::cout << "Name: " << name << std::endl;
        std::cout << "Quantity: " << quantity << std::endl;
        std::cout << "Price: " << std::fixed << std::setprecision(2) << price << std::endl;
    }

    double getTotalCost() {
        return quantity * price;
    }
};

#endif