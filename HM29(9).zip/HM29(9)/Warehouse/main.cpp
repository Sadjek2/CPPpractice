#include "Product.h"

int main() {
    Product monitor;

    monitor.name = "Monitor";
    monitor.quantity = 15;
    monitor.price = 15000.0;

    monitor.print();
    std::cout << "Total cost: " << monitor.getTotalCost() << std::endl;

    return 0;
}