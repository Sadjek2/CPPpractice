#include "LightBulb.h"

int main() {
    LightBulb bulb;

    std::cout << "Initial state: " << bulb.getState() << std::endl;

    bulb.turnOn();
    std::cout << "After turnOn(): " << bulb.getState() << std::endl;

    bulb.toggle();
    std::cout << "After toggle(): " << bulb.getState() << std::endl;

    bulb.turnOff();
    std::cout << "After turnOff(): " << bulb.getState() << std::endl;

    return 0;
}