#pragma once
#ifndef LIGHTBULB_H
#define LIGHTBULB_H

#include <iostream>

class LightBulb {
private:
    bool isOn;

public:
    LightBulb() : isOn(false) {}

    void turnOn() {
        isOn = true;
    }

    void turnOff() {
        isOn = false;
    }

    void toggle() {
        isOn = !isOn;
    }

    const char* getState() {
        if (isOn) return "ON";
        else return "OFF";
    }
};

#endif