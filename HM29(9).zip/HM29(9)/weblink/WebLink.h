#ifndef WEBLINK_H
#define WEBLINK_H

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstring>

class WebLink {
private:
    char* url;
    char* description;

public:
    WebLink(const char* linkUrl, const char* linkDesc) {
        size_t lenUrl = strlen(linkUrl);
        url = new char[lenUrl + 1];
        strcpy(url, linkUrl);

        size_t lenDesc = strlen(linkDesc);
        description = new char[lenDesc + 1];
        strcpy(description, linkDesc);
    }

    ~WebLink() {
        if (url) delete[] url;
        if (description) delete[] description;
    }

    void print() {
        std::cout << "Description: " << description << std::endl;
        std::cout << "URL: " << url << std::endl;
    }
};

#endif