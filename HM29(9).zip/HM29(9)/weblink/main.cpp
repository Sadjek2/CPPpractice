#define _CRT_SECURE_NO_WARNINGS

#include "WebLink.h"

int main() {
    WebLink mySite("https://academy.top", "Computer Academy Site");

    mySite.print();

    return 0;
}