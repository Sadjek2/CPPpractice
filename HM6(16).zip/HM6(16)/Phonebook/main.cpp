#include "Phonebook.h"

int main() {
    Phonebook pb;
    int choice = 0;
    String name(50);

    do {
        cout << "\n1. Add\n2. Delete\n3. Find\n4. Show all\n5. Exit\n> ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1: pb.add(); break;
        case 2: cout << "Last name: "; name.input(); pb.remove(name); break;
        case 3: cout << "Last name: "; name.input(); pb.find(name); break;
        case 4: pb.showAll(); break;
        }
    } while (choice != 5);

    cout << "Humans created: " << Human::getCount() << endl;
    return 0;
}