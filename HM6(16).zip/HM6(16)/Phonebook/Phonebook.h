#define _CRT_SECURE_NO_WARNINGS
#pragma once
#pragma once
#include <iostream>
#include <cstring>
#include <vector>
using namespace std;

// ============== CLASS STRING ==============
class String {
private:
    char* str;
    int len;
public:
    String(int size = 80);
    String(const char* inputStr);
    String(const String& other);
    ~String();

    void input();
    void print() const { cout << str; }
    const char* c_str() const { return str; }
    bool operator==(const String& other) const;
};

// ============== CLASS DATE ==============
class Date {
private:
    int day, month, year;
public:
    Date(int d = 1, int m = 1, int y = 2000);
    void setDate(int d, int m, int y);
    void print() const { cout << day << "." << month << "." << year; }
};

// ============== CLASS HUMAN ==============
class Human {
private:
    int id;
    String lastName, firstName, patronymic;
    Date birthDate;
    static int count;
public:
    Human(int _id = 0, String ln = String(50), String fn = String(50),
        String pat = String(50), Date bd = Date());
    Human(const Human& other);
    ~Human();

    static int getCount() { return count; }
    const String& getLastName() const { return lastName; }
    void print() const;
};

// ============== CLASS SUBSCRIBER ==============
class Subscriber {
private:
    Human person;
    String homePhone, workPhone, mobilePhone, extraInfo;
public:
    Subscriber();
    Subscriber(const Human& h, const String& home, const String& work,
        const String& mob, const String& extra);
    ~Subscriber();

    const String& getLastName() const { return person.getLastName(); }
    void print() const;
};

// ============== CLASS PHONEBOOK ==============
class Phonebook {
private:
    vector<Subscriber> subs;
public:
    void add();
    void remove(const String& lastName);
    void find(const String& lastName) const;
    void showAll() const;
};

// ============== REALIZATION ==============

// String
String::String(int size) : len(size) {
    str = new char[len + 1];
    str[0] = '\0';
}

String::String(const char* inputStr) {
    len = strlen(inputStr);
    str = new char[len + 1];
    strcpy(str, inputStr);
}

String::String(const String& other) : len(other.len) {
    str = new char[len + 1];
    strcpy(str, other.str);
}

String::~String() { delete[] str; }

void String::input() {
    char temp[1024];
    cin.getline(temp, 1024);
    delete[] str;
    len = strlen(temp);
    str = new char[len + 1];
    strcpy(str, temp);
}

bool String::operator==(const String& other) const {
    return strcmp(str, other.str) == 0;
}

// Date
Date::Date(int d, int m, int y) : day(d), month(m), year(y) {}
void Date::setDate(int d, int m, int y) { day = d; month = m; year = y; }

// Human
int Human::count = 0;

Human::Human(int _id, String ln, String fn, String pat, Date bd)
    : id(_id), lastName(ln), firstName(fn), patronymic(pat), birthDate(bd) {
    count++;
}

Human::Human(const Human& other)
    : id(other.id), lastName(other.lastName), firstName(other.firstName),
    patronymic(other.patronymic), birthDate(other.birthDate) {
    count++;
}

Human::~Human() { count--; }

void Human::print() const {
    cout << "ID: " << id << endl;
    lastName.print(); cout << " ";
    firstName.print(); cout << " ";
    patronymic.print(); cout << endl;
    cout << "Born: "; birthDate.print(); cout << endl;
}

// Subscriber
Subscriber::Subscriber()
    : person(), homePhone(15), workPhone(15), mobilePhone(15), extraInfo(100) {
}

Subscriber::Subscriber(const Human& h, const String& home, const String& work,
    const String& mob, const String& extra)
    : person(h), homePhone(home), workPhone(work), mobilePhone(mob), extraInfo(extra) {
}

Subscriber::~Subscriber() {}

void Subscriber::print() const {
    person.print();
    cout << "Home: "; homePhone.print(); cout << endl;
    cout << "Work: "; workPhone.print(); cout << endl;
    cout << "Mobile: "; mobilePhone.print(); cout << endl;
    cout << "Info: "; extraInfo.print(); cout << endl;
    cout << "========================\n";
}

// Phonebook
void Phonebook::add() {
    String ln(50), fn(50), pat(50), home(15), work(15), mob(15), extra(100);
    int d, m, y, id;

    cout << "\n=== New Subscriber ===" << endl;
    cout << "ID: "; cin >> id; cin.ignore();
    cout << "Last name: "; ln.input();
    cout << "First name: "; fn.input();
    cout << "Patronymic: "; pat.input();
    cout << "Birth (day month year): "; cin >> d >> m >> y; cin.ignore();
    cout << "Home phone: "; home.input();
    cout << "Work phone: "; work.input();
    cout << "Mobile phone: "; mob.input();
    cout << "Extra info: "; extra.input();

    Date bd(d, m, y);
    Human h(id, ln, fn, pat, bd);
    Subscriber s(h, home, work, mob, extra);
    subs.push_back(s);
    cout << "Added!\n";
}

void Phonebook::remove(const String& lastName) {
    for (size_t i = 0; i < subs.size(); i++) {
        if (subs[i].getLastName() == lastName) {
            subs.erase(subs.begin() + i);
            cout << "Deleted!\n";
            return;
        }
    }
    cout << "Not found!\n";
}

void Phonebook::find(const String& lastName) const {
    for (size_t i = 0; i < subs.size(); i++) {
        if (subs[i].getLastName() == lastName) {
            subs[i].print();
            return;
        }
    }
    cout << "Not found!\n";
}

void Phonebook::showAll() const {
    for (size_t i = 0; i < subs.size(); i++) subs[i].print();
}