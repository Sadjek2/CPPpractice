#include "Array.h"

int main() {
    // Создаем массив из 5 элементов
    Array a(5);

    // Заполняем
    a.input();

    // Выводим
    cout << "Array: ";
    a.print();

    // Минимум и максимум
    cout << "Min: " << a.getMin() << endl;
    cout << "Max: " << a.getMax() << endl;

    // Сортируем
    a.sort();
    cout << "Sorted: ";
    a.print();

    // Изменяем размер
    a.resize(7);
    cout << "Resized to 7: ";
    a.print();

    // Копия массива
    Array b(a);
    cout << "Copy: ";
    b.print();

    return 0;
}