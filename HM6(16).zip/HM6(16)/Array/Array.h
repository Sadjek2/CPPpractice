#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include <fstream>
using namespace std;

// CLASS ARRAY
class Array {
private:
    int* arr;
    int size;
public:
    Array(int s = 10);              // Конструктор с размером
    Array(const Array& other);    // Конструктор копирования
    ~Array();

    void input();        // Заполнение массива с клавиатуры
    void print() const;  // Вывод массива на экран
    void resize(int newSize); // Изменение размера
    void sort();         // Сортировка (пузырьком)
    int getMin() const;  // Минимум
    int getMax() const;  // Максимум

    int getSize() const { return size; }
};

// REALIZATION

Array::Array(int s) : size(s) {
    arr = new int[size];
    for (int i = 0; i < size; i++) arr[i] = 0;
}

Array::Array(const Array& other) : size(other.size) {
    arr = new int[size];
    for (int i = 0; i < size; i++) arr[i] = other.arr[i];
}

Array::~Array() {
    delete[] arr;
}

void Array::input() {
    cout << "Enter " << size << " elements:" << endl;
    for (int i = 0; i < size; i++) {
        cout << "arr[" << i << "] = ";
        cin >> arr[i];
    }
}

void Array::print() const {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void Array::resize(int newSize) {
    int* newArr = new int[newSize];
    int copySize = (newSize < size) ? newSize : size;

    for (int i = 0; i < copySize; i++) {
        newArr[i] = arr[i];
    }
    for (int i = copySize; i < newSize; i++) {
        newArr[i] = 0;
    }

    delete[] arr;
    arr = newArr;
    size = newSize;
}

void Array::sort() {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int Array::getMin() const {
    int min = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] < min) min = arr[i];
    }
    return min;
}

int Array::getMax() const {
    int max = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] > max) max = arr[i];
    }
    return max;
}