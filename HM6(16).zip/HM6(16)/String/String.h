#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class String {
private:
    char* str;
    int len;
public:
    String(int size = 80);              // Конструктор по умолчанию / произвольного размера
    String(const char* inputStr);       // Конструктор с инициализацией
    String(const String& other);      // Конструктор копирования
    ~String();

    void input();
    void print() const;
    const char* c_str() const { return str; }
    int length() const { return len; }
};

String::String(int size) : len(size) {
    str = new char[len + 1];
    str[0] = '\0';
}

String::String(const char* inputStr) {
    len = strlen(inputStr);
    str = new char[len + 1];
    strcpy(str, inputStr);
}

String::String(const String& other) : len(other.len) {
    str = new char[len + 1];
    strcpy(str, other.str);
}

String::~String() {
    delete[] str;
}

void String::input() {
    char temp[1024];
    cout << "> ";
    cin.getline(temp, 1024);
    delete[] str;
    len = strlen(temp);
    str = new char[len + 1];
    strcpy(str, temp);
}

void String::print() const {
    if (str) cout << str;
}