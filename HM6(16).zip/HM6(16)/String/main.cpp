#include "String.h"

int main() {
    // Конструктор по умолчанию (80 символов)
    String s1;
    cout << "s1 (default 80): ";
    s1.print();
    cout << endl;

    // Конструктор произвольного размера
    String s2(50);
    cout << "s2 (size 50): ";
    s2.print();
    cout << endl;

    // Конструктор с инициализацией
    String s3("Hello, World!");
    cout << "s3 (init): ";
    s3.print();
    cout << endl;

    // Конструктор копирования
    String s4(s3);
    cout << "s4 (copy): ";
    s4.print();
    cout << endl;

    // Ввод с клавиатуры
    cout << "\nEnter new string: ";
    String s5;
    s5.input();
    cout << "You entered: ";
    s5.print();
    cout << endl;

    return 0;
}